Archive manifest sample
